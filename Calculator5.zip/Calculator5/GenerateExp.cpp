#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <time.h>
#include <vector>

const int _probNegative = 15;   // 出现负数的概率，取值 [0,100]
const int _probDecimal = 10;    // 出现小数的概率，取值 [0,30]
const int _maxItem = 10;        // 表达式最大项数
const int _maxVal = 10;         // 生成数的最大值

std :: vector <double> arr;
std :: vector <int> opt;

int lb [_maxItem + 1], rb [_maxItem + 1];

int main () {
    srand ((unsigned) time (0));

    int n = 1 + rand () % _maxItem;
    for (int i = 1; i <= n; ++ i) {
        double x;
        x = rand () % _maxVal;
        int neg, dec;
        neg = rand () % 101;
        dec = rand () % 101;
        if (neg < _probNegative)
            x *= -1;
        if (dec < _probDecimal) {
            double d;
            d = (rand () % (_maxVal * 10)) / 100.0;
            x += d;
        }
        arr.push_back (x);
    }

    for (int i = 1; i < n; ++ i) {
        int x = rand () % 5;
        opt.push_back (x);
    }

    int br = rand () % (n / 2);
    for (int i = 1; i <= br; ++ i) {
        int l = rand () % n;
        int r = rand () % n;
        //while (l == r)
        //    r = rand () % n;
        if (l > r)
            std :: swap (l, r);
        ++ lb [l];
        ++ rb [r];
    }

    for (int i = 0; i < n; ++ i) {
        for (int j = 1; j <= lb[i]; ++ j)
            std :: cout << "(";
        if (arr [i] > 0)
            std :: cout << arr [i];
        else
            std :: cout << "(" << arr [i] << ")";
        for (int j = 1; j <= rb[i]; ++ j)
            std :: cout << ")";
        if (i != n - 1)
            switch (opt [i]) {
                case 0:
                    std :: cout << "+";
                    break;
                case 1:
                    std :: cout << "-";
                    break;
                case 2:
                    std :: cout << "*";
                    break;
                case 3:
                    std :: cout << "/";
                    break;
                case 4:
                    std :: cout << "^";
                    break;
            }
    }
    std :: cout << std :: endl;

    return 0;
}