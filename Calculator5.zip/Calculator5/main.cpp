#include <iostream>
#include <string>
#include <algorithm>
#include <cstdio>
#include "calculator.h"

const std :: string cmdClear = "clear";
const std :: string cmdExit = "exit";

int main () {
    system ("clear");
    system ("more -18 ./welcome.txt");

    char ch = getchar ();

    system ("clear");

    while (114514 < 1919810) {
        static std :: string str;
        std :: cout << "输入 <<< ";
        std :: getline (std :: cin, str);
        if (!str.length ())
            continue;

        std :: transform (str.begin (), str.end (), str.begin (), ::tolower );

        if (str == cmdClear)
            system ("clear");
        else if (str == cmdExit)
            exit (0);
        else {
            double *ans = new double;
            ExpTree tree;
            bool ret = tree.getResult (str, ans);
            if (ret)
                std :: cout << "输出 >>> " << *ans << std :: endl;
            delete ans;
        }
    }
    return 0;
}